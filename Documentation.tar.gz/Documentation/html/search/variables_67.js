var searchData=
[
  ['gain',['gain',['../classReadDataFile.html#ac1dd2f7b4bbd886aa6ba15431c4f3476',1,'ReadDataFile']]]
];
