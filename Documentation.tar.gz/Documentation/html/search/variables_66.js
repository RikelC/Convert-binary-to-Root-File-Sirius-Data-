var searchData=
[
  ['fcoboframe',['fCoboframe',['../classReadDataFile.html#a1955fc04355237a13c4aefc92dc63ed0',1,'ReadDataFile']]],
  ['fframe',['fFrame',['../classReadDataFile.html#ad1087ed9cbb1721c821612906759467c',1,'ReadDataFile']]],
  ['fgenericframe',['fGenericframe',['../classReadDataFile.html#a999805e5469446d6c5b74f9427f6bce2',1,'ReadDataFile']]],
  ['finsideframe',['fInsideframe',['../classReadDataFile.html#af2f7eabb61fc7c94b7b7e598576661ff',1,'ReadDataFile']]],
  ['fmergeframe',['fMergeframe',['../classReadDataFile.html#a890f1ad1aaa809a3b19a36d846bd1a37',1,'ReadDataFile']]],
  ['framesize',['framesize',['../classReadDataFile.html#a705f23128c41039dfab914c732cc0e3f',1,'ReadDataFile']]],
  ['fsiriusframe',['fSiriusframe',['../classReadDataFile.html#a2f02f25217db8f8671f87e3d0ba37c7e',1,'ReadDataFile']]]
];
