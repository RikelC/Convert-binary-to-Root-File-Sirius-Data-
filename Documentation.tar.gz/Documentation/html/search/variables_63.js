var searchData=
[
  ['channel',['channel',['../classReadDataFile.html#adf1a3e11f025d11090261e38ae87a91f',1,'ReadDataFile']]]
];
