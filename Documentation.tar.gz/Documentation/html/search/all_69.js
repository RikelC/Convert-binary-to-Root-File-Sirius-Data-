var searchData=
[
  ['initialize_5fttree',['initialize_ttree',['../classReadDataFile.html#ac23e016626800b79c353eb87581ce290',1,'ReadDataFile']]],
  ['is_5fa_5fnew_5frun',['is_a_new_run',['../ConvertToRootFile_8cc.html#a4efffbb612efeaf69d3e354094245560',1,'ConvertToRootFile.cc']]]
];
