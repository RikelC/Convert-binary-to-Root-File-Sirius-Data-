var searchData=
[
  ['max_5fnevents_5fto_5fprocess',['max_nEvents_to_process',['../classReadDataFile.html#aa13a8fef4dce2d12ef174a3ef2c27a55',1,'ReadDataFile']]]
];
